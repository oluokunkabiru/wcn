<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<!-- <link rel="stylesheet" href="fontawesome-free/css/all.css"> -->

	<link rel="stylesheet" href="{{ asset('assets/css/animate.css') }}">

	<link rel="stylesheet" href="{{ asset('assets/css/owl.carousel.min.css') }}">
	<link rel="stylesheet" href="{{ asset('assets/css/owl.theme.default.min.css') }}">
	<link rel="stylesheet" href="{{ asset('assets/css/magnific-popup.css') }}">


	<link rel="stylesheet" href="{{ asset('assets/css/bootstrap-datepicker.css') }}">
	<link rel="stylesheet" href="{{ asset('assets/css/jquery.timepicker.css') }}">

	<link rel="stylesheet" href="{{ asset('assets/css/flaticon.css') }}">
	<link rel="stylesheet" href="{{ asset('assets/css/style.css') }}">
	<link rel="stylesheet" href="{{ asset('assets/nstyle.css') }}">
	<link rel="stylesheet" href="{{ asset('assets/cstyle.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/lc_lightbox.min.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/minimal.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/style.css') }}">

	<link rel="stylesheet" href="{{ asset('assets/summernote/summernote-bs4.css') }}">

    <style>
        /* .active{
               background-color: #dba928;
                font-size: 230px;
            } */
		#more {display: none;}
		nav div ul li a {
			color: black!important;
			font-size:20px;
			}

		nav div ul li a: .active {
				color: gold !important;
			}
			.carousel-inner img {
			width: 100%;
			height: auto;
			}

		body{
			font-family:'georgia';
		}
        .bottomleft {
    position: absolute;
    bottom: 20px;
    left: 26px;
    font-size: 18px;
}


	</style>
@yield('style')
