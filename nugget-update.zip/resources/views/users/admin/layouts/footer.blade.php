 <!-- Start app Footer part -->
 <footer class="main-footer">
    <div class="footer-left">
        <div class="bullet"></div> FRSC &copy; {{ date('Y') }} All Rights Reserved | Design by <a href="https://github.com/oluokunkabiru">KOADIT</a>
    </div>
    <div class="footer-right">

    </div>
</footer>
