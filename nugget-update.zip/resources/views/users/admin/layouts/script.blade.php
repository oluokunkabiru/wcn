<script src="{{ asset('assets/users/assets/bundles/lib.vendor.bundle.js') }}"></script>
<script src="{{ asset('assets/users/assets/modules/dist/min/dropzone.min.js') }}"></script>

<script src="{{ asset('assets/users/js/CodiePie.js') }}"></script>

<!-- JS Libraies -->
<script src="{{ asset('assets/users/assets/modules/apexcharts/apexcharts.min.js') }}"></script>
<script src="{{ asset('assets/users/assets/modules/simple-weather/jquery.simpleWeather.min.js') }}"></script>
<script src="{{ asset('assets/users/assets/modules/jqvmap/dist/jquery.vmap.min.js') }}"></script>
<script src="{{ asset('assets/users/assets/modules/jqvmap/dist/maps/jquery.vmap.world.js') }}"></script>
<script src="{{ asset('assets/users/assets/modules/summernote/summernote-bs4.js') }}"></script>
<script src="{{ asset('assets/users/assets/modules/chocolat/dist/js/jquery.chocolat.min.js') }}"></script>
<script src="{{ asset('assets/users/assets/modules/datatables/datatables.min.js') }}"></script>
<script src="{{ asset('assets/users/assets/modules/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js') }}"></script>

<script src="{{ asset('assets/users/assets/modules/select2/dist/js/select2.full.min.js') }}"></script>

<!-- Page Specific JS File -->
<script src="{{ asset('assets/users/js/page/index-0.js') }}"></script>

<!-- Template JS File -->
<script src="{{ asset('assets/users/js/scripts.js') }}"></script>
